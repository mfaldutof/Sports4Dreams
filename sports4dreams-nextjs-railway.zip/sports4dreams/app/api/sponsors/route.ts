import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(request: Request) {
  const data = await request.formData();
  await prisma.sponsor.create({
    data: {
      company: String(data.get('company') || ''),
      contactName: String(data.get('contactName') || '') || null,
      email: String(data.get('email') || '') || null,
      phone: String(data.get('phone') || '') || null,
      tier: String(data.get('tier') || 'supporter'),
      contribution: String(data.get('contribution') || '') || null,
    },
  });
  return NextResponse.redirect(new URL('/sponsor?success=1', request.url));
}
