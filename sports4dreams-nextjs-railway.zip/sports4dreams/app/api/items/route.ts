import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  const items = await prisma.equipmentItem.findMany({ orderBy: { createdAt: 'desc' }, take: 100, include: { donor: true, beneficiary: true } });
  return NextResponse.json(items);
}
