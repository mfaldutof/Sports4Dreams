import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { makeItemCode } from '@/lib/codes';

export async function POST(request: Request) {
  const data = await request.formData();
  const donor = await prisma.donor.create({
    data: {
      name: String(data.get('name') || ''),
      email: String(data.get('email') || '') || null,
      phone: String(data.get('phone') || '') || null,
      city: String(data.get('city') || '') || null,
      consent: data.get('consent') === 'true',
    },
  });
  await prisma.equipmentItem.create({
    data: {
      code: makeItemCode(),
      category: String(data.get('category') || 'OTHER') as any,
      type: String(data.get('type') || ''),
      brand: String(data.get('brand') || '') || null,
      size: String(data.get('size') || '') || null,
      condition: String(data.get('condition') || 'bueno'),
      story: String(data.get('story') || '') || null,
      donorId: donor.id,
    },
  });
  return NextResponse.redirect(new URL('/donate?success=1', request.url));
}
