import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  const [items, delivered, beneficiaries, organizations, sponsors] = await Promise.all([
    prisma.equipmentItem.count(),
    prisma.equipmentItem.count({ where: { status: 'DELIVERED' } }),
    prisma.beneficiary.count(),
    prisma.organization.count(),
    prisma.sponsor.count(),
  ]);
  return NextResponse.json({ items, delivered, beneficiaries, organizations, sponsors });
}
