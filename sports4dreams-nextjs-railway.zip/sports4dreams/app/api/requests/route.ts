import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(request: Request) {
  const data = await request.formData();
  let organizationId: string | undefined;
  const organizationName = String(data.get('organizationName') || '');
  if (organizationName) {
    const org = await prisma.organization.create({
      data: {
        name: organizationName,
        type: 'applicant',
        email: String(data.get('contactEmail') || '') || null,
        phone: String(data.get('contactPhone') || '') || null,
      },
    });
    organizationId = org.id;
  }
  await prisma.beneficiary.create({
    data: {
      name: String(data.get('name') || ''),
      age: data.get('age') ? Number(data.get('age')) : null,
      sport: String(data.get('sport') || ''),
      community: String(data.get('community') || '') || null,
      need: String(data.get('need') || ''),
      urgency: String(data.get('urgency') || 'medium'),
      organizationId,
    },
  });
  return NextResponse.redirect(new URL('/request-support?success=1', request.url));
}
