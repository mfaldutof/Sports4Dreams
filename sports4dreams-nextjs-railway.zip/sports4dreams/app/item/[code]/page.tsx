import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { prisma } from '@/lib/prisma';
import { notFound } from 'next/navigation';
import { Bike, Calendar, Heart, ShieldCheck, User } from 'lucide-react';

export default async function ItemPage({ params }: { params: Promise<{ code: string }> }) {
  const { code } = await params;
  let item:any = null;
  try { item = await prisma.equipmentItem.findUnique({ where: { code }, include: { donor: true, beneficiary: true, delivery: true } }); } catch {}
  if (!item && code !== 'S4D-CIC-000078') notFound();
  item = item || { code, type:'Bicicleta de Ruta Specialized Tarmac', category:'CYCLING', brand:'Specialized', size:'54', condition:'Excelente estado', status:'DELIVERED', story:'Usada durante competencias nacionales en 2021. Hoy impulsa nuevos sueños sobre dos ruedas.', donor:{name:'Carlos A.'}, beneficiary:{name:'Juan P.'} };
  return <><Header /><main className="container section"><section className="story-panel" style={{padding:0, overflow:'hidden', borderRadius:18}}>
    <div className="bike-visual"><Bike size={150} /></div>
    <div style={{padding:34}}>
      <span className="badge">{item.status}</span>
      <h1 style={{fontSize:56, margin:'18px 0 6px'}}>{item.code}</h1>
      <h2 style={{fontSize:30}}>{item.type}</h2>
      <div className="story-meta"><span>{item.category}</span><span>{item.brand || 'Marca no registrada'}</span><span>Talla {item.size || '-'}</span><span>{item.condition}</span></div>
      <h2>Historia del equipo</h2>
      <p>{item.story || 'Este artículo forma parte de Sports 4 Dreams y está en proceso de trazabilidad.'}</p>
      <div className="grid">
        <div className="card"><User /><b>Donado por</b><p>{item.donor?.name || 'Donante no publicado'}</p></div>
        <div className="card"><Heart /><b>Entregado a</b><p>{item.beneficiary?.name || 'Pendiente de asignación'}</p></div>
        <div className="card"><ShieldCheck /><b>Trazabilidad</b><p>Registrado, validado y listo para reporte.</p></div>
      </div>
      <p><Calendar size={16} /> Fecha de entrega: en actualización</p>
    </div>
  </section></main><Footer /></>;
}
