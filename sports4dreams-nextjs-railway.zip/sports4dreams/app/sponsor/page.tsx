import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { SubmitButton } from '@/components/SubmitButton';
import { ArrowRight, BarChart3, Handshake, ShieldCheck } from 'lucide-react';

export default function SponsorPage() {
  return <><Header /><main className="container section"><div className="form-shell">
    <aside className="form-hero">
      <span className="badge">Patrocinio ESG</span>
      <h1>Impacto visible para marcas que hacen.</h1>
      <p>Financia logística, campañas, almacenamiento, transporte o equipamiento nuevo. Te entregamos historias, métricas y trazabilidad.</p>
      <div className="grid" style={{gridTemplateColumns:'1fr', marginTop:24}}>
        <div className="card"><BarChart3 /> <b>Métricas</b><p>Equipos recuperados, entregas, beneficiarios y organizaciones.</p></div>
        <div className="card"><ShieldCheck /> <b>Evidencia</b><p>Fotos, testimonios, códigos y reportes de impacto.</p></div>
        <div className="card"><Handshake /> <b>Activaciones</b><p>Campañas de donación con empleados, atletas y comunidades.</p></div>
      </div>
    </aside>
    <section className="card">
      <h2>Patrocinar Sports 4 Dreams</h2><p>Cuéntanos cómo puede participar tu empresa.</p>
      <form className="form" action="/api/sponsors" method="POST">
        <input name="company" placeholder="Empresa" required />
        <input name="contactName" placeholder="Nombre de contacto" />
        <input name="email" type="email" placeholder="Email" />
        <input name="phone" placeholder="Teléfono" />
        <select name="tier"><option value="supporter">Supporter</option><option value="bronze">Bronce</option><option value="silver">Plata</option><option value="gold">Oro</option><option value="title">Titular</option></select>
        <textarea name="contribution" placeholder="Cómo quieren apoyar: dinero, logística, espacio, transporte, producto..." />
        <SubmitButton>Contactar como patrocinador <ArrowRight size={16} /></SubmitButton>
      </form>
    </section>
  </div></main><Footer /></>;
}
