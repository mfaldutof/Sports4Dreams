import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { SubmitButton } from '@/components/SubmitButton';
import { ArrowRight, Building2, Users, ClipboardCheck } from 'lucide-react';

export default function RequestSupportPage() {
  return <><Header /><main className="container section"><div className="form-shell">
    <aside className="form-hero">
      <span className="badge">Solicitud de apoyo</span>
      <h1>Conectamos equipo con necesidad real.</h1>
      <p>Registra a un beneficiario, club, escuela o fundación. Priorizamos casos verificables y con responsable local.</p>
      <div className="grid" style={{gridTemplateColumns:'1fr', marginTop:24}}>
        <div className="card"><Users /> <b>Jóvenes</b><p>Atletas y niños que necesitan equipamiento.</p></div>
        <div className="card"><Building2 /> <b>Organizaciones</b><p>Escuelas, clubes, fundaciones y entrenadores.</p></div>
        <div className="card"><ClipboardCheck /> <b>Validación</b><p>Solicitudes priorizadas por urgencia e impacto.</p></div>
      </div>
    </aside>
    <section className="card">
      <h2>Solicitar apoyo</h2><p>Cuéntanos qué necesita el beneficiario y cómo podemos verificar la entrega.</p>
      <form className="form" action="/api/requests" method="POST">
        <input name="name" placeholder="Nombre del beneficiario o responsable" required />
        <input name="age" type="number" placeholder="Edad del beneficiario" />
        <input name="sport" placeholder="Deporte" required />
        <input name="community" placeholder="Comunidad / zona" />
        <textarea name="need" placeholder="Qué necesita y por qué" required />
        <select name="urgency"><option value="medium">Prioridad media</option><option value="high">Prioridad alta</option><option value="low">Prioridad baja</option></select>
        <input name="organizationName" placeholder="Organización, escuela o club asociado" />
        <input name="contactEmail" type="email" placeholder="Email de contacto" />
        <input name="contactPhone" placeholder="Teléfono / WhatsApp" />
        <SubmitButton>Enviar solicitud <ArrowRight size={16} /></SubmitButton>
      </form>
    </section>
  </div></main><Footer /></>;
}
