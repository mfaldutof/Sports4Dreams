import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { SubmitButton } from '@/components/SubmitButton';
import { ArrowRight, PackageCheck, ShieldCheck, Heart } from 'lucide-react';

export default function DonatePage() {
  return <><Header /><main className="container section"><div className="form-shell">
    <aside className="form-hero">
      <span className="badge">Donación trazable</span>
      <h1>Dona el equipo que ya no usas.</h1>
      <p>Cada artículo se registra, valida y conecta con un joven, club o comunidad que lo necesita.</p>
      <div className="grid" style={{gridTemplateColumns:'1fr', marginTop:24}}>
        <div className="card"><PackageCheck /> <b>Recibimos</b><p>Zapatillas, balones, uniformes, bicicletas, raquetas y más.</p></div>
        <div className="card"><ShieldCheck /> <b>Validamos</b><p>Solo entregamos equipo en buen estado y con uso real.</p></div>
        <div className="card"><Heart /> <b>Transformamos</b><p>Tu equipo puede ser el inicio del sueño de otro.</p></div>
      </div>
    </aside>
    <section className="card">
      <h2>Registrar donación</h2><p>Completa la información para sumar el artículo al inventario Sports 4 Dreams.</p>
      <form className="form" action="/api/donations" method="POST">
        <input name="name" placeholder="Nombre del donante" required />
        <input name="email" type="email" placeholder="Email" />
        <input name="phone" placeholder="Teléfono / WhatsApp" />
        <input name="city" placeholder="Ciudad" />
        <select name="category" required><option value="RUNNING">Running</option><option value="FOOTBALL">Fútbol</option><option value="CYCLING">Ciclismo</option><option value="TENNIS">Tenis</option><option value="BASKETBALL">Basketball</option><option value="OTHER">Otro</option></select>
        <input name="type" placeholder="Tipo de artículo: zapatillas, balón, bicicleta..." required />
        <input name="brand" placeholder="Marca" />
        <input name="size" placeholder="Talla / medida" />
        <select name="condition" required><option value="excelente">Excelente</option><option value="bueno">Bueno</option><option value="usable">Usable</option><option value="requiere_revision">Requiere revisión</option></select>
        <textarea name="story" placeholder="Historia del artículo: competencias, uso, por qué lo donas..." />
        <label><input name="consent" type="checkbox" value="true" /> Autorizo usar la historia de la donación</label>
        <SubmitButton>Registrar donación <ArrowRight size={16} /></SubmitButton>
      </form>
    </section>
  </div></main><Footer /></>;
}
