import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Sports 4 Dreams',
  description: 'Equipamiento deportivo reutilizado para niños y jóvenes.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
