import { prisma } from '@/lib/prisma';
import { BarChart3, Bike, Building2, PackageCheck, Shirt, Users } from 'lucide-react';

export default async function DashboardPage() {
  let items:any[] = [], beneficiaries:any[] = [], sponsors:any[] = [];
  let counts = { items: 142, delivered: 128, beneficiaries: 96, sponsors: 23 };
  try {
    [items, beneficiaries, sponsors] = await Promise.all([
      prisma.equipmentItem.findMany({ orderBy: { createdAt: 'desc' }, take: 25, include: { donor: true, beneficiary: true } }),
      prisma.beneficiary.findMany({ orderBy: { createdAt: 'desc' }, take: 10 }),
      prisma.sponsor.findMany({ orderBy: { createdAt: 'desc' }, take: 10 }),
    ]);
    counts = {
      items: await prisma.equipmentItem.count(),
      delivered: await prisma.equipmentItem.count({ where: { status: 'DELIVERED' } }),
      beneficiaries: await prisma.beneficiary.count(),
      sponsors: await prisma.sponsor.count(),
    };
  } catch {}

  return <main className="dashboard-layout">
    <aside className="sidebar">
      <a className="brand" href="/"><span>SPORTS</span><b>4</b><span>DREAMS</span><small>Admin console</small></a>
      <nav className="grid" style={{gridTemplateColumns:'1fr', marginTop:36}}>
        <a className="badge" href="/dashboard">Dashboard</a>
        <a href="/donate">Donaciones</a>
        <a href="/request-support">Beneficiarios</a>
        <a href="/sponsor">Patrocinadores</a>
      </nav>
    </aside>
    <section className="dash-main">
      <div className="dashboard-head" style={{marginBottom:24}}>
        <div><p className="eyebrow">Resumen general</p><h1 style={{fontSize:42, margin:0}}>Impact Dashboard</h1></div>
        <a className="btn ghost" href="/">Volver al sitio</a>
      </div>
      <div className="dash-grid">
        <div className="metric-card"><Shirt /><b>{counts.items}</b><span>Equipos recibidos</span><small>+18% vs mes anterior</small></div>
        <div className="metric-card"><PackageCheck /><b>{counts.delivered}</b><span>Equipos entregados</span><small>+22% vs mes anterior</small></div>
        <div className="metric-card"><Users /><b>{counts.beneficiaries}</b><span>Jóvenes beneficiados</span><small>+15% vs mes anterior</small></div>
        <div className="metric-card"><Building2 /><b>{counts.sponsors}</b><span>Aliados</span><small>+9% vs mes anterior</small></div>
      </div>
      <div className="charts-row" style={{marginBottom:20}}>
        <div className="line-chart card-dark"><h3><BarChart3 size={16}/> Impacto acumulado</h3><div className="chart-lines"><span /><span /></div><div className="months">Ene Feb Mar Abr May Jun Jul Ago Sep Oct Nov Dic</div></div>
        <div className="card-dark"><h3><Bike size={16}/> Equipo destacado</h3><div className="bike-visual" style={{minHeight:180}}><Bike size={90} /></div><p>S4D-CIC-000078 · Bicicleta de ruta · Entregado</p></div>
      </div>
      <section className="card">
        <h2>Inventario reciente</h2>
        {items.length ? <table className="table"><thead><tr><th>Código</th><th>Artículo</th><th>Categoría</th><th>Estado</th><th>Donante</th></tr></thead><tbody>
          {items.map(item => <tr key={item.id}><td><a href={`/item/${item.code}`}>{item.code}</a></td><td>{item.type}</td><td>{item.category}</td><td><span className="badge">{item.status}</span></td><td>{item.donor?.name || '-'}</td></tr>)}
        </tbody></table> : <div className="empty">Cuando conectes Railway PostgreSQL y empiecen a entrar donaciones, el inventario aparecerá aquí.</div>}
      </section>
      <div className="grid">
        <section className="card"><h2>Solicitudes</h2>{beneficiaries.length ? beneficiaries.map(b => <p key={b.id}><b>{b.name}</b><br />{b.sport} · {b.community || 'Sin zona'} · {b.urgency}</p>) : <p>No hay solicitudes todavía.</p>}</section>
        <section className="card"><h2>Patrocinadores</h2>{sponsors.length ? sponsors.map(s => <p key={s.id}><b>{s.company}</b><br />{s.tier} · {s.contribution || 'Pendiente'}</p>) : <p>No hay patrocinadores registrados todavía.</p>}</section>
        <section className="card"><h2>Próximo sprint</h2><p>Login admin, carga de fotos, edición de estados, asignación de beneficiarios y generación automática de QR.</p></section>
      </div>
    </section>
  </main>;
}
