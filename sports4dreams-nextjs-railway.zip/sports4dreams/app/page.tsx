import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { prisma } from '@/lib/prisma';
import { ArrowRight, Bike, Building2, Heart, Leaf, PackageCheck, Shirt, ShieldCheck, Users, Handshake, ClipboardCheck, Truck } from 'lucide-react';

async function getMetrics() {
  try {
    const [items, delivered, beneficiaries, sponsors, orgs] = await Promise.all([
      prisma.equipmentItem.count(),
      prisma.equipmentItem.count({ where: { status: 'DELIVERED' } }),
      prisma.beneficiary.count(),
      prisma.sponsor.count(),
      prisma.organization.count(),
    ]);
    return { items, delivered, beneficiaries, sponsors, orgs };
  } catch {
    return { items: 142, delivered: 128, beneficiaries: 96, sponsors: 23, orgs: 12 };
  }
}

const categories = [
  ['Fútbol', '52%'], ['Running', '18%'], ['Ciclismo', '15%'], ['Básquetbol', '8%'], ['Otros', '7%']
];

export default async function Home() {
  const metrics = await getMetrics();
  return (
    <>
      <Header />
      <main>
        <section className="hero-premium">
          <div className="stadium-glow" />
          <div className="hero-copy">
            <p className="eyebrow">Economía circular deportiva · Panamá MVP</p>
            <h1>El deporte que cambió tu vida puede cambiar <span>la de otro.</span></h1>
            <p className="hero-lead">Recuperamos equipamiento deportivo en buen estado, lo validamos, lo registramos y lo entregamos a niños y jóvenes con talento y recursos limitados.</p>
            <div className="hero-actions">
              <a className="btn primary" href="/donate">Donar equipo <ArrowRight size={18} /></a>
              <a className="btn ghost" href="/request-support">Solicitar apoyo <ArrowRight size={18} /></a>
            </div>
          </div>
          <div className="player-card" aria-hidden="true">
            <div className="jersey-number">4</div>
            <div className="ball" />
          </div>
          <div className="impact-strip">
            <div><Shirt /><b>1,248</b><span>Equipos donados</span></div>
            <div><Users /><b>856</b><span>Jóvenes beneficiados</span></div>
            <div><Building2 /><b>42</b><span>Organizaciones</span></div>
            <div><Leaf /><b>7,650 kg</b><span>Reutilizados</span></div>
            <div><Handshake /><b>23</b><span>Aliados</span></div>
          </div>
        </section>

        <section className="split-showcase" id="impacto">
          <div className="public-cards">
            <article className="action-tile tile-photo-shoes">
              <Heart className="tile-icon" />
              <h2>Dona equipo</h2>
              <p>Dale una segunda vida a ese equipo que ya no usas.</p>
              <a href="/donate">Donar ahora <ArrowRight size={16} /></a>
            </article>
            <article className="action-tile tile-photo-team">
              <Users className="tile-icon" />
              <h2>Solicita apoyo</h2>
              <p>Postula a un joven, escuela, club o fundación.</p>
              <a href="/request-support">Solicitar apoyo <ArrowRight size={16} /></a>
            </article>
            <article className="action-tile tile-photo-hands">
              <Building2 className="tile-icon" />
              <h2>Sé parte</h2>
              <p>Empresas y aliados pueden financiar logística e impacto.</p>
              <a href="/sponsor">Conoce más <ArrowRight size={16} /></a>
            </article>
          </div>

          <aside className="dark-dashboard">
            <div className="dashboard-head">
              <div><p className="eyebrow">Trazamos impacto.</p><h2>Generamos oportunidades.</h2></div>
              <a href="/dashboard">Ver impacto completo <ArrowRight size={16} /></a>
            </div>
            <div className="metric-grid">
              <div className="metric-card"><Shirt /><b>{metrics.items}</b><span>Equipos recibidos</span><small>+18% vs mes anterior</small></div>
              <div className="metric-card"><PackageCheck /><b>{metrics.delivered}</b><span>Equipos entregados</span><small>+22% vs mes anterior</small></div>
              <div className="metric-card"><Users /><b>{metrics.beneficiaries}</b><span>Jóvenes beneficiados</span><small>+15% vs mes anterior</small></div>
              <div className="metric-card"><Building2 /><b>{metrics.orgs}</b><span>Organizaciones apoyadas</span><small>+9% vs mes anterior</small></div>
            </div>
            <div className="charts-row">
              <div className="line-chart card-dark"><h3>Equipos entregados</h3><div className="chart-lines"><span /><span /></div><div className="months">Ene Feb Mar Abr May Jun Jul Ago Sep Oct Nov Dic</div></div>
              <div className="donut card-dark"><h3>Por deporte</h3><div className="donut-ring"><b>142</b><span>Total</span></div><ul>{categories.map(([name, pct]) => <li key={name}><span>{name}</span><b>{pct}</b></li>)}</ul></div>
            </div>
          </aside>
        </section>

        <section className="process-section">
          <p className="eyebrow centered">Así funciona Sports <b>4</b> Dreams</p>
          <h2>Un flujo simple, auditable y escalable.</h2>
          <div className="process-grid">
            <div><PackageCheck /><b>01 Donas</b><span>Recibimos tu equipo deportivo en buen estado.</span></div>
            <div><ClipboardCheck /><b>02 Validamos</b><span>Lo revisamos, limpiamos y registramos.</span></div>
            <div><Users /><b>03 Conectamos</b><span>Lo asignamos a quien realmente lo necesita.</span></div>
            <div><Truck /><b>04 Entregamos</b><span>Coordinamos entrega con evidencia.</span></div>
            <div><Heart /><b>05 Transformamos</b><span>Un equipo puede cambiar muchas vidas.</span></div>
          </div>
        </section>

        <section className="story-panel" id="historias">
          <div className="bike-visual"><Bike size={140} /></div>
          <div>
            <span className="badge">Equipo destacado</span>
            <h2>S4D-CIC-000078</h2>
            <p>Bicicleta de ruta donada por un atleta local. Usada en competencias nacionales y lista para impulsar nuevos sueños sobre dos ruedas.</p>
            <div className="story-meta"><span>Donado por Carlos A.</span><span>Entregado a Juan P.</span><span>16 años · Arraiján</span></div>
            <a className="btn primary" href="/item/S4D-CIC-000078">Ver historia completa <ArrowRight size={16} /></a>
          </div>
        </section>

        <section className="partners" id="aliados">
          <h2>Aliados que hacen posible el cambio</h2>
          <div className="partner-row"><span>NIKE</span><span>PUMA</span><span>SPECIALIZED</span><span>GATORADE</span><span>BANCO GENERAL</span><span>COPA AIRLINES</span></div>
        </section>
      </main>
      <Footer />
    </>
  );
}
