export function makeItemCode() {
  const year = new Date().getFullYear();
  const random = Math.floor(100000 + Math.random() * 900000);
  return `S4D-PA-${year}-${random}`;
}
