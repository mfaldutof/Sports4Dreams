import { Instagram, Linkedin, Mail, Youtube } from 'lucide-react';

export function Footer() {
  return (
    <footer className="footer" id="contacto">
      <div>
        <div className="footer-brand">SPORTS <b>4</b> DREAMS</div>
        <p>El deporte que cambió tu vida puede cambiar la vida de alguien más.</p>
      </div>
      <form className="newsletter">
        <Mail size={20} />
        <input placeholder="Tu correo electrónico" aria-label="Correo electrónico" />
        <button type="button">Suscribirme</button>
      </form>
      <div className="socials"><Instagram /><Linkedin /><Youtube /></div>
    </footer>
  );
}
