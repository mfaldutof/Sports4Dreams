'use client';
import { useState } from 'react';

export function SubmitButton({ children }: { children: React.ReactNode }) {
  const [loading, setLoading] = useState(false);
  return <button className="btn primary" type="submit" onClick={() => setLoading(true)} disabled={loading}>{loading ? 'Enviando...' : children}</button>;
}
