import { ArrowRight, Menu } from 'lucide-react';

export function Header() {
  return (
    <header className="site-header">
      <a className="brand" href="/" aria-label="Sports 4 Dreams home">
        <span>SPORTS</span><b>4</b><span>DREAMS</span>
        <small>Equipment. Opportunity. Impact.</small>
      </a>
      <nav className="nav-links" aria-label="Main navigation">
        <a href="/">Inicio</a>
        <a href="/#impacto">Impacto</a>
        <a href="/#historias">Historias</a>
        <a href="/#aliados">Aliados</a>
        <a href="/dashboard">Dashboard</a>
      </nav>
      <a className="header-cta" href="/donate">Donar equipo <ArrowRight size={16} /></a>
      <button className="mobile-menu" aria-label="Open menu"><Menu size={22} /></button>
    </header>
  );
}
